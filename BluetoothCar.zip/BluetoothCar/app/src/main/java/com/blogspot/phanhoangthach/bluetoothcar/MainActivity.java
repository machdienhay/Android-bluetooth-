package com.blogspot.phanhoangthach.bluetoothcar;

import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;

import android.widget.SeekBar;
import android.widget.Toast;
import android.app.ProgressDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.os.AsyncTask;

import java.io.IOException;
import java.util.UUID;


import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends ActionBarActivity {

    Button btn_up,btn_down,btn_left,btn_right;
    Button btn_1,btn_2,btn_3,btn_4,btn_stop;
    String address = null;
    int btn_up_string=0,btn_down_string=0,btn_left_string=0,btn_right_string=0;
    int btn_1_string=0,btn_2_string=0,btn_3_string=0,btn_4_string=0;
    int btn_stop_string=0,tocdo=94;
    private ProgressDialog progress;
    BluetoothAdapter myBluetooth = null;
    BluetoothSocket btSocket = null;
    private boolean isBtConnected = false;
    //SPP UUID. Look for it
    static final UUID myUUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Intent newint = getIntent();
        address = newint.getStringExtra(ketnoi.EXTRA_ADDRESS); //receive the address of the bluetooth device



        //call the widgtes
        btn_up = (Button)findViewById(R.id.btn_up);
        btn_down = (Button)findViewById(R.id.btn_down);
        btn_left = (Button)findViewById(R.id.btn_left);
        btn_right = (Button)findViewById(R.id.btn_right);
        btn_1 = (Button)findViewById(R.id.btn_1);
        btn_2 = (Button)findViewById(R.id.btn_2);
        btn_3 = (Button)findViewById(R.id.btn_3);
        btn_4 = (Button)findViewById(R.id.btn_4);
        btn_stop = (Button)findViewById(R.id.btn_stop);
        new ConnectBT().execute(); //Call the class to connect

        final SeekBar seek=(SeekBar) findViewById(R.id.seekBar);
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                // TODO Auto-generated method stub
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                // TODO Auto-generated method stub
            }

            @Override
            public void onProgressChanged(SeekBar seekBar, int progress,boolean fromUser) {
                // TODO Auto-generated method stub
                tocdo=progress;
                btn_stop_string = 0;
                btn_1_string = 0;
                btn_2_string = 0;
                btn_3_string = 0;
                btn_4_string = 0;
                send_data();
            }
        });


        btn_left.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    btn_left_string = 100;
                    btn_stop_string = 0;
                    btn_1_string = 0;
                    btn_2_string = 0;
                    btn_3_string = 0;
                    btn_4_string = 0;
                    send_data();
                } else if (event.getAction() == MotionEvent.ACTION_UP) {
                    btn_left_string = 0;
                    btn_stop_string = 0;
                    btn_1_string = 0;
                    btn_2_string = 0;
                    btn_3_string = 0;
                    btn_4_string = 0;
                    send_data();
                }
                return true;
            }
        });

        btn_right.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    btn_right_string=100;
                    btn_stop_string=0;
                    btn_1_string=0;
                    btn_2_string=0;
                    btn_3_string=0;
                    btn_4_string=0;
                    send_data();
                } else if (event.getAction() == MotionEvent.ACTION_UP) {
                    btn_right_string=0;
                    btn_stop_string=0;
                    btn_1_string=0;
                    btn_2_string=0;
                    btn_3_string=0;
                    btn_4_string=0;
                    send_data();
                }
                return true;
            }
        });

        btn_up.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    btn_up_string=100;
                    btn_stop_string=0;
                    btn_1_string=0;
                    btn_2_string=0;
                    btn_3_string=0;
                    btn_4_string=0;
                    send_data();
                } else if (event.getAction() == MotionEvent.ACTION_UP) {
                    btn_up_string=0;
                    btn_stop_string=0;
                    btn_1_string=0;
                    btn_2_string=0;
                    btn_3_string=0;
                    btn_4_string=0;
                    send_data();
                }
                return true;
            }
        });

        btn_down.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    btn_down_string=100;
                    btn_stop_string=0;
                    btn_1_string=0;
                    btn_2_string=0;
                    btn_3_string=0;
                    btn_4_string=0;
                    send_data();
                } else if (event.getAction() == MotionEvent.ACTION_UP) {
                    btn_down_string=0;
                    btn_stop_string=0;
                    btn_1_string=0;
                    btn_2_string=0;
                    btn_3_string=0;
                    btn_4_string=0;
                    send_data();
                }
                return true;
            }
        });


        btn_stop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                btn_stop_string = 100;
                btn_1_string = 0;
                btn_2_string = 0;
                btn_3_string = 0;
                btn_4_string = 0;
                send_data();
            }
        });
        btn_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                btn_stop_string=0;
                btn_1_string=100;
                btn_2_string=0;
                btn_3_string=0;
                btn_4_string=0;
                send_data();
            }
        });
        btn_2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                btn_stop_string=0;
                btn_1_string=0;
                btn_2_string=100;
                btn_3_string=0;
                btn_4_string=0;
                send_data();
            }
        });
        btn_3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                btn_stop_string=0;
                btn_1_string=0;
                btn_2_string=0;
                btn_3_string=100;
                btn_4_string=0;
                send_data();
            }
        });
        btn_4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                btn_stop_string=0;
                btn_1_string=0;
                btn_2_string=0;
                btn_3_string=0;
                btn_4_string=100;
                send_data();
            }
        });


    }


    private void send_data()
    {
        if (btSocket!=null)
        {
            try
            {
                btSocket.getOutputStream().write("*".toString().getBytes());
                btSocket.getOutputStream().write(btn_up_string);
                btSocket.getOutputStream().write(btn_down_string);
                btSocket.getOutputStream().write(btn_left_string);
                btSocket.getOutputStream().write(btn_right_string);
                btSocket.getOutputStream().write(btn_stop_string);
                btSocket.getOutputStream().write(btn_1_string);
                btSocket.getOutputStream().write(btn_2_string);
                btSocket.getOutputStream().write(btn_3_string);
                btSocket.getOutputStream().write(btn_4_string);
                btSocket.getOutputStream().write(tocdo);
                btSocket.getOutputStream().write("#".toString().getBytes());

            }
            catch (IOException e)
            {
                disconnect();
                //msg("Đã có lỗi xảy ra ,có thể đã mất kết nối với thiết bị");
            }
        }
    }
    private void disconnect()
    {
        if (btSocket!=null) //If the btSocket is busy
        {
            try
            {
                btSocket.close(); //close connection
            }
            catch (IOException e)
            { //msg("Đã có lổi xảy ra");
                Toast.makeText(getApplicationContext(), "Đã có lổi xảy ra", Toast.LENGTH_LONG).show();
            }
        }
        isBtConnected = false;
        finish(); //return to the first layout

    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if(id == R.id.action_thoat)
        {
            disconnect();
            return true;
        }
        if (id == R.id.action_settings) {
            Intent i = new Intent(MainActivity.this, about.class);
            startActivity(i);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
    private class ConnectBT extends AsyncTask<Void, Void, Void>  // UI thread
    {
        private boolean ConnectSuccess = true; //if it's here, it's almost connected

        @Override
        protected void onPreExecute()
        {
            progress = ProgressDialog.show(MainActivity.this, "Đang kết nối với thiết bị...", "Xin đợi trong giây lát...");  //show a progress dialog
        }

        @Override
        protected Void doInBackground(Void... devices) //while the progress dialog is shown, the connection is done in background
        {
            try
            {
                if (btSocket == null || !isBtConnected)
                {
                    myBluetooth = BluetoothAdapter.getDefaultAdapter();//get the mobile bluetooth device
                    BluetoothDevice dispositivo = myBluetooth.getRemoteDevice(address);//connects to the device's address and checks if it's available
                    btSocket = dispositivo.createInsecureRfcommSocketToServiceRecord(myUUID);//create a RFCOMM (SPP) connection
                    BluetoothAdapter.getDefaultAdapter().cancelDiscovery();
                    btSocket.connect();//start connection
                }
            }
            catch (IOException e)
            {
                ConnectSuccess = false;//if the try failed, you can check the exception here
            }
            return null;
        }
        @Override
        protected void onPostExecute(Void result) //after the doInBackground, it checks if everything went fine
        {
            super.onPostExecute(result);

            if (!ConnectSuccess)
            {
               //msg("Kết nối thất bại, không dúng với thiết bị hoặc thiết bị đã tắt, xin hãy thử lại");
                Toast.makeText(getApplicationContext(), "Kết nối thất bại, không dúng với thiết bị hoặc thiết bị đã tắt, xin hãy thử lại", Toast.LENGTH_LONG).show();
                finish();
            }
            else
            {
                Toast.makeText(getApplicationContext(), "Đã kết nối thành công với thiết bị.", Toast.LENGTH_LONG).show();
                isBtConnected = true;
            }
            progress.dismiss();
        }
    }
}
